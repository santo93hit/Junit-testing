/**
 * 
 */
package com.junit.demo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**
 * @author kusantosh
 *
 */
class MathUtilsTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
