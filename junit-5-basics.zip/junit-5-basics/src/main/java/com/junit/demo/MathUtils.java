package com.junit.demo;

public class MathUtils {
	
	public int add(int a,int b) {
		return a + b;
	}
}
