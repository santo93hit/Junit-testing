package com.junit.testing.sub;

import static org.assertj.core.api.Assertions.fail;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assumptions.assumeTrue;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.RepetitionInfo;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestReporter;
import org.junit.jupiter.api.condition.EnabledOnOs;
import org.junit.jupiter.api.condition.OS;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)// By default instance is created per method now it become per class
class MathUtilsTest {
	
	MathUtils mathUtils;
	TestInfo testInfo;
	TestReporter testReporter;
	
	// When you are using @BeforeAll or @AfterAll annotation at any method 
	// then that method must be a static method because test class method 
	// is getting initiated when @Test method is getting call or till that 
	// time class object is not initiated to run the test methods
	
	// Note :- if @TestInstance is having per class then static keyword is not
	// required when using @BeforeAll and @AfterAll
	
	@BeforeAll
	static void beforeAllInit() {
		System.out.println("This needs to run before all");
	}
	
	@BeforeEach
	void init(TestInfo testInfo,TestReporter testReporter) {
		this.testInfo = testInfo;
		this.testReporter = testReporter;
		mathUtils = new MathUtils();
		testReporter.publishEntry("Running "+ testInfo.getDisplayName()+ " with Tag "+testInfo.getTags());// Using these two you can get all info about test methods 
	}
	
	@AfterEach
	void cleanUp() {
		System.out.println("Cleaning Up.......");
	}
	
	@Test
	@Tag("Math")// By using this @tag annotation you can separate it out which are the method you wan to run using eclipse configuration or maven configuration 
	@DisplayName("Add Method for adding Two Number.") // To display method detail in console to identify which method we are testing
	void testAdd() {
		int expected = 1;
		boolean isDbConnectionUp = false;
		assumeTrue(isDbConnectionUp);// By using this we can check any dependency kind of stuff
		int actual = mathUtils.add(0, 1);
		assertEquals(expected, actual, () -> "Should return sum "+ expected +" but returned " + actual ); // here message will execute and form when test is fails due to lambda expression
	}
	
	@Nested
	@Tag("Math")
	@DisplayName("add Methods")
	class AddTest {
		
		@Test
		@DisplayName("When adding two positive number.")
		void testAddPositiveNumber() {
			assertEquals(2, mathUtils.add(1, 1),"Should return right sum.");
		}
		
		@Test
		@DisplayName("When adding two positive number.")
		void testAddNegativeNumber() {
			assertEquals(-2, mathUtils.add(-1,-1),"Should return right sum.");
		}
	}
	
	@Test
	@Tag("Math")
	@DisplayName("Test Multiply Method")
	void testMultiply() {
//		assertEquals(1, mathUtils.multiply(-1,-1),"Should return right multiplication.");
		assertAll(
				() -> assertEquals(4,mathUtils.multiply(2,2)),
				() -> assertEquals(6,mathUtils.multiply(2,3)),
				() -> assertEquals(-4,mathUtils.multiply(-1,4)),
				() -> assertEquals(1,mathUtils.multiply(-1,-1))
		);
		
		
	}
	
	@Test
	@Tag("Area")
	void tetsComputedCircleArea() {
		assertEquals(314.1592653589793, mathUtils.computedCircleArea(10),"Should return right circle area.");
	}
	
	@Test
	@Tag("Math")
	@EnabledOnOs(OS.LINUX) // Similar to Disabled some other method also we have like this
	void testDivide() {
//		MathUtils mathUtils = new MathUtils();
		assertThrows(ArithmeticException.class,() -> mathUtils.divide(1, 0),"Divide by zero should throw exception.");
//		assertThrows(NullPointerException.class,() -> mathUtils.divide(1, 0),"Divide by zero should throw exception.");
	}
	
	@Test
	@Tag("Disabled")
	@DisplayName("TDD(Test Driven Devlopment) method. Should not run.")
	@Disabled
	void testDisabled() {
		fail("Test Disabled Annotation.");
	}
	
	@RepeatedTest(3)
	@Tag("Math")
	void tetsSubtraction(RepetitionInfo repetitionInfo) {
//		MathUtils mathUtils = new MathUtils();
		if(repetitionInfo.getCurrentRepetition() == 1) {
			assertEquals(1, mathUtils.subtract(2, 1), () -> "Should return right difference.");
		}else if(repetitionInfo.getCurrentRepetition() == 2) {
			assertEquals(5, mathUtils.subtract(6, 1), () -> "Should return right difference.");
		}else if(repetitionInfo.getCurrentRepetition() == 3) {
			assertEquals(-1, mathUtils.subtract(1,2), () -> "Should return right difference.");
		}
	}
	
	@Test
	void testIsvalidExpression() {
		String expression = "[{()}()]";
		assertEquals(true, mathUtils.isValidExpression(expression),() ->"Not a valid expression"+expression);
	}

}
