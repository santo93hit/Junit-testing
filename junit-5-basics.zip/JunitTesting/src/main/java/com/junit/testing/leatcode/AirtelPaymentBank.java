package com.junit.testing.leatcode;

import java.util.StringTokenizer;

public class AirtelPaymentBank {

	public static void main(String[] args) {
		AirtelPaymentBank airtelPaymentBank = new AirtelPaymentBank();
		// Q1.) Return intern to whom passcode belongs using Day(i) = Day(i-1) + 5000 + i; All intern got hired for 50 days only.
		//		First day passcode value for any intern will be Day(0) = 5000* (kth intern). i.e for 1st intern value will be 5000*1=5000
		//      Ex- : { [input : 2,5000] [output : 1] [exp : 1st intern 1st day passcode]} , { [input : 10,25003] [output : 3] [exp : 3rd intern 3rd day passcode]}
		
		System.out.println(airtelPaymentBank.getInternToWhomPassCodeBelongs(10,25003));
		//Q2.) Return correct word count after left rotation of each words by k times.
		//	   Ex- : {[input : 'lloeh erthe' , 2] [output : 0] [exp : 'oehll there' that means no word is similar]} , 
		//           {[input : 'adaada' , 3] [output : 1] [exp : 'adaada' that means 1 word is similar]}
		//		     {[input : 'mad dma' , 2] [output : 1] [exp : 'dma adm' that means 1(dma) word is similar]}
//		String testCases[] = {"lloeh erthe_2","adaada_3","mad dma_2"};
//		for(String testCase : testCases) {
//			System.out.println("[ input : "+testCase+" ] [ output : "+airtelPaymentBank.rotatedWordCount(testCase.split("_")[0], Integer.parseInt(testCase.split("_")[1]))+" ]");
//		}
	}

	public int rotatedWordCount(String sentence,int k) {
		StringTokenizer strToken = new StringTokenizer(sentence," ");
		int correctWordCount =0;
		while(strToken.hasMoreTokens()) {
			String wordToken = strToken.nextToken().toString();
			String rotatedWord = wordToken.substring(k)+wordToken.substring(0, k);
			if(sentence.contains(" "+rotatedWord+" ")) {
				correctWordCount++;
			}
		}
		return correctWordCount;
	}
	
	public int getInternToWhomPassCodeBelongs(int n,int passCode) {
		for(int i=1;i<=n;i++) {
			int initialPasscodeForIntern = 5000*i;
			int day=1;
			while(initialPasscodeForIntern != passCode && initialPasscodeForIntern<passCode) {
				initialPasscodeForIntern = initialPasscodeForIntern + 5000 + day;
				day++;
			}
			if(passCode==initialPasscodeForIntern) {
				return i;
			}
		}
		return -1;
	}
}
