package com.junit.testing.leatcode;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class PlusOne {
	public static int[] plusOne(int[] digits) {
		int l = digits.length;
		int i=l-1;
		for(;i>=0;i--){
			int sum=digits[i]+1;
			if(!(sum>=10 && sum%10 >= 0)){
				digits[i]=sum;
				return digits;
			}else if(sum>=10 && sum%10 >= 0){
				digits[i]=sum%10;
			}
		}
		int arr[]=new int [l+1];
		arr[0]=1;
		for(int j=0;j<l;j++){
			arr[j+1]=digits[j];
		}
		return arr;
	}
	
	public static int[] plusOne1(int[] digits) {
        int n = digits.length;
        for(int i = n-1;i>=0;i--){
            if(digits[i]<9){
                digits[i]++;
                return digits;
            }
            digits[i] = 0;
        }
        
        int[] newNumber = new int[n+1];
        newNumber[0] = 1;
        return newNumber;
    }

	public static void main(String[] args) throws IOException{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
//		int n = Integer.parseInt(br.readLine());
//		int a[] = new int[n];
//		for(int i=0;i<n;i++){
//			a[i] = Integer.parseInt(br.readLine());
//		}
		int a[] = {2,3};
		int result[] = plusOne1(a);
		for(int k : result){
			System.out.print(k+", ");
		}
		//System.out.println(index);
	}
}
