package com.junit.testing.leatcode;

public class Test {

    /**
     * @param args
     */
    public static void main(String[] args) {

//        String slist[] = new String[] { 
//                "/mnt/sdcard/folder1/a/b/file1.file", 
//                "/mnt/sdcard/folder1/a/b/file2.file", 
//                "/mnt/sdcard/folder1/a/b/file3.file", 
//                "/mnt/sdcard/folder1/a/b/file4.file",
//                "/mnt/sdcard/folder1/a/b/file5.file", 
//                "/mnt/sdcard/folder1/e/c/file6.file", 
//                "/mnt/sdcard/folder2/d/file7.file", 
//                "/mnt/sdcard/folder2/d/file8.file", 
//                "/mnt/sdcard/file9.file" 
//        };
        
        String paths[] = {
        				   "testFolder/0/05706990021654/10/1574931005462~~sh2_re1.pdf", 
        				   "testFolder/0/05706990021654/10/1574931343438~~sh2_re2.pdf", 
        				   "testFolder/0/05706990021654/10/1574931366579~~sh2_re3.pdf", 
        				   "testFolder/0/05706990021654/14/1575008934456~~support 2.pdf", 
        				   "testFolder/0/05706990021654/14/1575008943014~~support1.pdf", 
        				   "testFolder/0/05706990021654/1582793959559~~000000.PNG", 
        				   "testFolder/1/01898979949991/1580274393990~~båäöü1.pdf", 
        				   "testFolder/1/03574661119151/1580281746597~~båäöü.xlsx", 
        				   "testFolder/1/03574661119151/1580288692694~~båäöü.pdf", 
        				   "testFolder/2/04008666704122/1580377744671~~m2.PNG", 
        				   "testFolder/2/04008666704122/1580385983897~~cm_product_tendÁ.PNG", 
        				   "testFolder/2/04008666704122/1581326193814~~cm_supplier_GLNRequestLiÄ.PNG",
        				   "testFolder/4/05052197039436/1578660068580~~4.PNG", 
        				   "testFolder/4/05052197039436/1578995034207~~145.PNG", 
        				   "testFolder/4/05706990021654/07313223146789/05052197039467/cm.PNG", 
        				   "testFolder/4/05706990021654/07313223146789/05052197039467/cm_product_tendÁ.PNG", 
        				   "testFolder/4/05706990021654/07313223146789/1download.jpg", 
        				   "testFolder/4/05706990021654/07313223146789/download.jpg", 
        				   "testFolder/4/05706990021654/download1.jpg"
        				  };


        MXMTree tree = new MXMTree(new MXMNode("root", "root"));
        for (String data : paths) {
            tree.addElement(data);
        }

        tree.printTree();
    }

}