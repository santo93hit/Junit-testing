package com.junit.testing.geeksforgeeks;

public class ArrayRotation {

	public static void main(String[] args) {
		ArrayRotation arrayRotation = new ArrayRotation();
		int a[] = {1,2,3,4,5,6,7};
//		arrayRotation.arrayLeftRotationUsingReverseConcept(a,2);
//		arrayRotation.arrayLeftRotation(a, 2);
//		arrayRotation.leftRotate(a,0, 2,a.length);
		arrayRotation.arrayRightRotation(a, 1);
		System.out.println("Outside : ");
		arrayRotation.printArray(a,a.length);
	}

	public int[] arrayLeftRotation(int a[],int d) {
		while(d-- > 0) {
			int temp = a[0],j;
			for(j=1;j<a.length;j++) {
				a[j-1]=a[j];
			}
			a[j-1]=temp;
		}
		return a;
	}
	
	public int[] arrayRightRotation(int a[],int d) {
		int len = a.length-1;
		while(d-- > 0) {
			int temp = a[len],j;
			for(j=len;j>0;j--) {
				a[j]=a[j-1];
			}
			a[j]=temp;
		}
		return a;
	}
	
	public int[] arrayLeftRotationUsingReverseConcept(int a[],int d) {
		int len = a.length;
		reverseArray(a,0,len-1);
		reverseArray(a,0,len-d-1);
		reverseArray(a,len-d,len-1);
		return a;
	}
	
	public int[] reverseArray(int a[],int low,int high) {
		while(low<=high) {
			int temp = a[low];
			a[low]=a[high];
			a[high]=temp;
			low++;
			high--;
		}
		return a;
	}
	
	// BLock Swap By Geeks for Geeks
	public void leftRotate(int arr[], int i,int d, int n) { 
		/* Return If number of elements to be rotated  
			is zero or equal to array size */
		if(d == 0 || d == n)  
			return;  

		/*If number of elements to be rotated  
			is exactly half of array size */
		if(n - d == d)  
		{  
			swap(arr, i, n - d + i, d);  
			return;  
		}  

		/* If A is shorter*/    
		if(d < n - d)  
		{  
			swap(arr, i, n - d + i, d);  
			leftRotate(arr, i, d, n - d);      
		}  
		else /* If B is shorter*/    
		{  
			swap(arr, i, d, n - d);  
			leftRotate(arr, n - d + i, 2 * d - n, d); /*This is tricky*/
		}  
} 

/*UTILITY FUNCTIONS*/
/* function to print an array */
	public void printArray(int arr[], int size){  
		int i;  
		for(i = 0; i < size; i++)  
			System.out.print(arr[i] + " ");  
		System.out.println();  
	}  

/*This function swaps d elements  
starting at index fi with d elements 
starting at index si */
	public void swap(int arr[], int fi,int si, int d) {  
		int i, temp;  
		for(i = 0; i < d; i++)  
		{  
			temp = arr[fi + i];  
			arr[fi + i] = arr[si + i];  
			arr[si + i] = temp;  
		}  
	} 
	
}
