package com.junit.testing.sub;

import java.util.Arrays;

//Recursion
public class RecursionExamples {

	public static void main(String[] args) {
		RecursionExamples recursionExamples = new RecursionExamples();
		System.out.println(recursionExamples.taylorSeries(2,10));
		int n = 6;
		int [] fib = new int[n+1];
		Arrays.fill(fib, -1);
		System.out.println(recursionExamples.fibonacciSeriesMemoization(n,fib));
		
	}

	//		1.) Tail Recursion :-> The function does not have to process any statement after recursive call. that means it has to do everything before 
	//		returning. That means all the processing statement should be executed before the every recursive call. This can be easily 
	//		converted into a loop. Example -> 

	public void tailRecur(int n) {
		if(n>0) {
			System.out.println(n);
			tailRecur(n-1);
		}
	}

	public void convertTailInLoop(int n) {
		while(n>0) {
			System.out.println(n);
			n--;
		}
	}


	//		2.) Head Recursion :-> The function does not have to process any statement before recursive call. that means it has to do everything before 
	//		at the time of returning. That means all the processing statement should be executed after all recursive call. This can not be easily 
	//		converted into a loop. Example ->  

	public void headRecur(int n) {
		if(n>0) {
			headRecur(n-1);
			System.out.println(n);
		}
	}

	public void convertHeadInLoop(int n) {
		int i=0;
		while(i<=n) {
			i++;
			System.out.println(i);
		}
	}

	//		3.) Tree Recursion :-> If a function is calling itself more than one time is called tree recursion. Complexity :-> Time : O(2^n), Space : O(n)

	public void treeRecur(int n) {
		if(n>0) {
			System.out.println(n);
			treeRecur(n-1);
			treeRecur(n-1);
		}
	}

	//		4.) Indirect Recursion :-> In indirect recursion there will be more than one function and they are calling one another in a circular fashion. indirectRecur1(20) 

	public void indirectRecur1(int n) {
		if(n>0) {
			System.out.println(n);
			indirectRecur2(n-1);
		}
	}

	public void indirectRecur2(int n) {
		if(n>1) {
			System.out.println(n);
			indirectRecur1(n/2);
		}
	}

	//		5.) Nested Recursion :-> A recursive function will pass parameter as a recursive call. Recursion inside recursion. Ex-> nestedRecur(95);

	public int nestedRecur(int n) {
		if(n>100) {
			return n-10;
		}else {
			return nestedRecur(nestedRecur(n+11));
		}
	}
	
	// Sum of n natural numbers using recursion :- or sum=n*(n+1)/2
	
	public int sumOfNaturalNumber(int n) {
		if(n==0) return 0;
		return sumOfNaturalNumber(n-1)+n;
	}
	
	// Factorial using recursion
	
	public int factorial(int n) {
		if(n==0 || n==1) return 1;
		return factorial(n-1)*n;
	}

	// Exponent function 
	
	public int powFunction(int n,int m) {
		if(m==0) {
			return 1;
		}
		return powFunction(n,m-1)*n;
	}
	
	//	Taylor Series code Ex-> 
//		e^x = 1 + x/1! + x^2/2! + x^3/3! + x^4/4! + ...... + x^n/n! 
//			= 1 + x/1 [ 1 + x/2 + (x^2/2*3) + (x^3/2*3*4) + ... + (x^n-1/2*3*... * (n-1))]
//	        = 1 + x/1 [ 1 + x/2 [1 + x/3 + (x^2/3*4) + ... + (x^n-2/3*... * (n-1))]] like this series will form
	
	double s=1;
	public double taylorSeries(int x,int n) {
		if(n==0) {
			return s;
		}else {
			s = 1 + s*x/n;
		}
		return taylorSeries(x, n-1);
	}
	
	// Fibonacci Series (Excessive Recursion)
	public int fibonacciSeries(int n) {
		if(n<=1) return n;
		else {
			return fibonacciSeries(n-2)+fibonacciSeries(n-1);
		}
	}
	
	// Memoization function to check term is already calculated or not
	
	public int fibonacciSeriesMemoization(int n,int fib[]) {
		if(n<=1) {
			fib[n]=n;
			return n;
		}
		else {
			if(fib[n-2]==-1) {
				fib[n-2]=fibonacciSeriesMemoization(n-2,fib);
			}
			if(fib[n-1]==-1) {
				fib[n-1]=fibonacciSeriesMemoization(n-1,fib);
			}
//			fib[n]=fib[n-2]+fib[n-1];
			return fib[n]=fib[n-2]+fib[n-1];
//			 fibonacciSeriesMemoization(n-2,fib)+fibonacciSeriesMemoization(n-1,fib);
		}
	}
}
