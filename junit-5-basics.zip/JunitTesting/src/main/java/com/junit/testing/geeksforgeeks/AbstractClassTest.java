package com.junit.testing.geeksforgeeks;

public class AbstractClassTest {

	public static void main(String[] args) {
		System.out.println("Super class reference variable : ");
		Car ref;
		ref = new Maruti();
		ref.registrationNumber=1234;
		ref.openTank();
		ref.breaking();
		ref.steering();
		
		ref = new Santro();
		ref.registrationNumber=1235;
		ref.openTank();
		ref.breaking();
		ref.steering();
		
		System.out.println("Sub class reference variable : ");
		Maruti mref = new Maruti();
		mref.registrationNumber=1236;
		mref.openTank();
		mref.breaking();
		mref.steering();
		
		Santro sref = new Santro();
		sref.registrationNumber=1237;
		sref.openTank();
		sref.breaking();
		sref.steering();
	}

}

abstract class Car{
	
	int registrationNumber;
	
	void openTank() {
		System.out.println("Concrete Method");
	}
	
	abstract void breaking();
	abstract void steering();
}

class Maruti extends Car{

	@Override
	void breaking() {
		System.out.println("Registration no. :- "+registrationNumber+" Hydrollic breaking system");
	}

	@Override
	void steering() {
		System.out.println("Registration no. :- "+registrationNumber+" Manual Steering");
	}
	
}

class Santro extends Car{

	@Override
	void breaking() {
		System.out.println("Registration no. :- "+registrationNumber+" Gas breaking system");
	}

	@Override
	void steering() {
		System.out.println("Registration no. :- "+registrationNumber+" Power Steering");
	}
	
}