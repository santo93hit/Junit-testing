package com.junit.testing.geeksforgeeks;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.io.PrintStream;

public class B extends Thread{

	/*
	 * public void walk(){ System.out.println("B walk()"); super.walk(); }
	 * 
	 * public void run() { super.run(); System.out.println("B run()"); }
	 */

	public synchronized void m1() throws FileNotFoundException {
		PrintStream o = new PrintStream(new File("C:/Users/kusantosh/Desktop/vlcnew/A.txt"));
		for(int i=0;i<1000;i++) {
			System.setOut(o); 
			System.out.println("Test : "+i);
		}
	}

	/*
	 * public static int pivotIndex(int[] nums) {
	 * 
	 * }
	 * 
	 * public static void main(String[] args) throws IOException{ BufferedReader br
	 * = new BufferedReader(new InputStreamReader(System.in)); int n =
	 * Integer.parseInt(br.readLine()); int a[] = new int[n]; for(int i=0;i<n;i++){
	 * a[i] = Integer.parseInt(br.readLine()); } int index = pivotIndex(a);
	 * System.out.println(index); }
	 */

	public static void main(String[] args) throws FileNotFoundException {
		int a[] = {0,1,1,-1,-1};
		int i=0;
		for(int j=i+1;j<a.length;j++) {
			if(a[i]!=a[j]) {
				while(j>(i+1)) {
					a[j-1]=a[j];
					j--;
				}
				i++;
			}
			/*
			 * if(a[i]!=a[j] && (j-i)>1) { a[++i]=a[j]; j=i+1; }
			 */
		}
		for(int k=0;k<(i+1);k++) {
			System.out.println(a[k]);
		}
		//		B b1 = new B(); 
		//		B b2 = new B(); 
		//		
		//			b1.start();
		//			b2.start();
		//		b.walk();
	}

	@Override
	public void run() {
		try {
			m1();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

}
