package com.junit.testing.geeksforgeeks;

public class A {
	public void walk(){
		System.out.println("A walk()");
		run();
	}
	public void run() {
		System.out.println("A run()");
	}
}
