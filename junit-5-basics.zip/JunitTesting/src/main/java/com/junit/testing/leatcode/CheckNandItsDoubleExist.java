package com.junit.testing.leatcode;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class CheckNandItsDoubleExist {

	public boolean binarySearch(int a[],int low,int high,int key,int i){
        if(low<=high){
            int mid = (low + high)/2;
            if(a[mid]==key && mid != i){
                return true;
            }else if(a[mid]<key){
                return binarySearch(a,mid+1,high,key,i);
            }else{
                return binarySearch(a,low,mid-1,key,i);
            }
        }else {
        	return false;
        }
    }
    
    public boolean checkIfExist(int[] arr) {
    	Arrays.sort(arr);
        for(int i=0;i<arr.length;i++){
            int temp = 2*arr[i];
            if(binarySearch(arr,0,arr.length-1,temp,i)){
                return true;
            }
        }
        return false;
    }
    
    
    public boolean checkIfExistUsingHashSet(int[] arr) {
    	Set<Integer> set = new HashSet<Integer>();
        for(int n : arr){
        	if((set.contains(n/2) && n%2==0 )|| set.contains(2*n)) {
        		return true;
        	}
        	set.add(n);
        }
        return false;
    }
    
    
	public static void main(String[] args) {
		CheckNandItsDoubleExist checkNandItsDoubleExist = new CheckNandItsDoubleExist();
		int a[]= {10,2,5,3};
//		System.out.println(checkNandItsDoubleExist.checkIfExist(a));
		System.out.println(checkNandItsDoubleExist.checkIfExistUsingHashSet(a));
	}

}
