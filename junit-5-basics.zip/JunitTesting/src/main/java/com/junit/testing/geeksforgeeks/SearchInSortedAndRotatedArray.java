package com.junit.testing.geeksforgeeks;

public class SearchInSortedAndRotatedArray {

	public static void main(String[] args) {
		SearchInSortedAndRotatedArray searchInSortedAndRotatedArray = new SearchInSortedAndRotatedArray();
		int a[] = {5, 6, 7, 8, 0,1 ,2 ,3 ,4}; 
	    int n = a.length; 
	    int key = 4; 
	    //System.out.println(searchInSortedAndRotatedArray.pivotedBinarySearch(a, n, key));
	    System.out.println(searchInSortedAndRotatedArray.binarySearchInOnePass(a, 0, n-1, key));
	}
	
	int pivotedBinarySearch(int a[], int n, int key) {
		int pivot = findPivotPoint(a,0,n-1);
		System.out.println(pivot);
		if(pivot==-1) {
	    	return binarySearch(a, 0, n-1, key);
	    }
		if(a[pivot]==key) {
			return pivot;
		}
		if(a[0]<=key) {
			return binarySearch(a,0,pivot-1,key);
		}
		return binarySearch(a,pivot+1,n-1,key);
	}
	
	int findPivotPoint(int arr[],int low,int high) {
		// base cases 
		if (high < low)   
			return -1; 
		if (high == low)  
			return low; 

		/* low + (high - low)/2; */
		int mid = (low + high)/2;    
		if (mid < high && arr[mid] > arr[mid + 1]) 
			return mid; 
		if (mid > low && arr[mid] < arr[mid - 1]) 
			return (mid-1); 
		if (arr[low] >= arr[mid]) 
			return findPivotPoint(arr, low, mid-1); 
		return findPivotPoint(arr, mid + 1, high); 
	}
	
	int binarySearch(int a[],int low,int high,int key) {
		if (high < low)   
			return -1; 
		int mid = (low+high)/2;
		if(a[mid]==key) {
			return mid;
		}else if(a[mid]<key) {
			return binarySearch(a,(mid+1),high,key);
		}
		return binarySearch(a,low,(mid-1),key);
	}
	
	int binarySearchInOnePass(int a[], int l, int h, int key) {
		int mid = (l+h)/2;
		if(key==a[mid])
			return mid;
		if(a[l]<=a[mid]) {
			if(key>=a[l] && key<=a[mid]) {
				return binarySearchInOnePass(a,l,mid-1,key);
			}
			return binarySearchInOnePass(a,mid+1,h,key);
		}
		if(key>=a[mid] && key<=a[h]){
			return binarySearchInOnePass(a,mid+1,h,key);
		}
		return binarySearchInOnePass(a,l,mid-1,key);
	}
	
	
	boolean pairInSortedRotated(int a[], int n, int x) {
		for(int i=0;i<a.length;i++) {
			for(int j=i;j<a.length;j++) {
				if((a[i]+a[j])==x) {
					return true;
				}
			}
		}
		return false;
	}
	
	boolean pairInSortedRotatedImproved(int a[], int l,int h, int x) {
		int mid = (l+h)/2;
		int temp=x-a[mid];
		if(temp<a[mid]) {
			
		}
		return false;
	}

}





