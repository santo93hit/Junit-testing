package com.junit.testing.leatcode;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class KWeakestRowsInAMatrix {

	public int[] kWeakestRows(int[][] mat, int k) {
        Map<Integer,Integer> map = new HashMap<Integer,Integer>();
        int rows[] = new int[k];
        for(int i=0;i<mat.length;i++){
            int noOfSoldiers = 0;
            for(int j=0;j<mat[i].length;j++){
                if(mat[i][j]==1) noOfSoldiers++;
            }
            map.put(i,noOfSoldiers);
        }
        Comparator<Entry<Integer, Integer>> valueComparator =	new Comparator<Entry<Integer,Integer>>() {
            @Override
            public int compare(Entry<Integer, Integer> e1, Entry<Integer, Integer> e2) {
            	Integer v1 = e1.getValue();
            	Integer v2 = e2.getValue();
                if(v1.compareTo(v2)==0) {
                	return e1.getKey().compareTo(e2.getKey());
                }
                return v1.compareTo(v2);
            }
        };
        List<Entry<Integer, Integer>> listOfEntries = new ArrayList<Entry<Integer, Integer>>(map.entrySet());
        Collections.sort(listOfEntries,valueComparator);
        
        int rowIndex = 0;
        for(Entry<Integer,Integer> entrySet : listOfEntries){
            if(k-->0){
                rows[rowIndex++]=entrySet.getKey();
            }
        }
        
        return rows;
    }
	
	public int[] kWeakestRows1(int[][] mat, int k) {
        int rows[] = new int[k];
        int rows1[] = new int[mat.length];
        for(int i=0;i<mat.length;i++){
            int noOfSoldiers = 0;
            for(int j=0;j<mat[i].length;j++){
                if(mat[i][j]==1) noOfSoldiers++;
            }
            rows1[i]=noOfSoldiers;
        }
        for(int i=0;i<k;i++){
        	int min = Integer.MAX_VALUE;
            int pos = 0;
            for(int j=0;j<rows1.length;j++){
                if(min>rows1[j] && rows1[j]!=-1){
                    min = rows1[j];
                    pos=j;
                }
            }
            rows1[pos]=-1;
            rows[i]=pos;
        }
        return rows;
    }
	public static void main(String[] args) throws IOException {
		/*
		 * KWeakestRowsInAMatrix kWeakestRowsInAMatrix = new KWeakestRowsInAMatrix();
		 * int mat[][] = {{1,1,0,0,0}, {1,1,1,1,0}, {1,0,0,0,0}, {1,1,0,0,0},
		 * {1,1,1,1,1}}; int rows[]=kWeakestRowsInAMatrix.kWeakestRows1(mat, 3); for(int
		 * r : rows) { System.out.print(r+" "); }
		 */
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String str = br.readLine();
		String strArray[] = str.split(" ");
		float x = Float.parseFloat(strArray[0]);
		float y = Float.parseFloat(strArray[1]);
		double result = y;
		if(y >= x && x%5==0){
			result = y-(x+0.50);
		}
		System.out.println(String.format("%.2f",result));
		/*
		 * if(y<x){ System.out.println(y); }else{ if(x%5!=0){ System.out.println(y);
		 * }else{ System.out.println(String.format("%.2f",(y-(x+0.50)))); } }
		 */
		
	}

}
