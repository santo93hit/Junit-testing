package com.junit.testing.sub;

import java.util.Stack;

public class MathUtils {
		
	public int add(int a,int b) {
		return a + b;
	}
	
	public double computedCircleArea(double radius) {
		return Math.PI * radius * radius;
	}
	
	public int divide(int a,int b) {
		return (a/b);
	}
	
	public int multiply(int a,int b) {
		return (a*b);
	}
	
	public int subtract(int a,int b) {
		return (a-b);
	}
	
	public Character getReverseBracket(Character b) {
		switch(b) {
			case '[' : return ']';
			case '{' : return ']';
			case '(' : return ']';
			case ']' : return '[';
			case '}' : return '{';
			case ')' : return '(';
		}
		return 'd';
	}
	
	public boolean isLeftBracket(Character b) {
		if(b.equals('[') || b.equals('{') || b.equals('(')) {
			return true;
		}
		return false;
	}
	
	public boolean isValidExpression(String expression) {
		Stack<Character> stack = new Stack<Character>();
		for(Character c : expression.toCharArray()) {
			Character rev = getReverseBracket(c);
			if(isLeftBracket(c)) {
				stack.push(c);
			}else if(stack.isEmpty() || stack.pop() != rev) {
				return false;
			}
		}
		return stack.isEmpty();
	}
	
}
